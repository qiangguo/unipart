#include <iostream>
#include <cstddef>
#include <string>
#include "define.h"
//#include "neuron.h"
//#include "weight.h"
#include "nn.h"


std::string NeuronType2Str(NeuronType nt) {
	std::string mapping = "Unknown";
	switch(nt) {
	case NeuronType::Input:
		mapping = "Input";
		break;
	case NeuronType::Hidden:
		mapping = "Hidden";
		break;
	case NeuronType::Output:
		mapping = "Output";
		break;
	default:
		break;
	}

	return mapping;
};

int main(int argc, char** argv) {
	NN nn = NN(2, 3, 1);
	nn.initialise();

	for (size_t i = 0; i < nn.getNumOfInputs(); i++) {
		std::cout << nn.m_input_neurons[i]->getID() << " "
				  << NeuronType2Str(nn.m_input_neurons[i]->getType()) << " : "
			      << (size_t) nn.m_input_neurons[i]->getType()
				  << std::endl;
	}

	std::cout << std::endl;
	
	for (size_t i = 0; i < nn.getNumOfHiddens(); i++) {
		std::cout << nn.m_hidden_neurons[i]->getID() << " "
				  << NeuronType2Str(nn.m_hidden_neurons[i]->getType()) << " : "
			      << (size_t) nn.m_hidden_neurons[i]->getType()
				  << std::endl;
	}

	std::cout << std::endl;

	for (size_t i = 0; i < nn.getNumOfOutputs(); i++) {
		std::cout << nn.m_output_neurons[i]->getID() << " "
				  << NeuronType2Str(nn.m_output_neurons[i]->getType()) << " : "
			      << (size_t) nn.m_output_neurons[i]->getType()
				  << std::endl;
	}
	
	return 0;
}
