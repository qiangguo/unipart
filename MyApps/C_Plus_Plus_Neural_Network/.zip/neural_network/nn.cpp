#include <iostream>
#include <random>
#include "nn.h"
#include "define.h"

/**

 **/
void NN::print_info(void) const {
	std::cout << "\n\n--------------------------------------------" << std::endl;
	std::cout << "*  Neural Network Structure:  "
			  << m_input_nums << " x "
			  << m_hidden_nums << " x "
			  << m_output_nums << "    *" << std::endl;
	std::cout << "--------------------------------------------\n\n" << std::endl;
}

/**

 **/
void NN::initialise(void) {
	std::random_device rd;
	std::default_random_engine gen_value(rd());
	std::uniform_real_distribution<double> DIST {0.0, 1.0};


	// Create Input Layer
	for (size_t i = 0; i < m_input_nums; i++) {
		m_input_neurons.emplace_back(
			std::shared_ptr<Neuron> {new Neuron(NEURON_ID_BASE+i,
												NeuronType::Input)});
	}

	// Create Hidden Layer
	for (size_t i = 0; i < m_hidden_nums; i++) {
		m_hidden_neurons.emplace_back(
			std::shared_ptr<Neuron> {new Neuron(NEURON_ID_BASE*2+i,
												NeuronType::Hidden)});
	}

	// Create weights between input and hidden neurons
	for (size_t i = 0; i < m_input_nums; i++) {		
		for (size_t j = 0; j < m_hidden_nums; j++){
			m_i2h_weights.emplace_back(
				std::shared_ptr<Weight> {new Weight(DIST(gen_value),
													m_input_neurons[i],
													m_hidden_neurons[j])});
		}
    }

	// Create Output Layer
	for (size_t i = 0; i < m_output_nums; i++) {
		m_output_neurons.emplace_back(
			std::shared_ptr<Neuron> {new Neuron(NEURON_ID_BASE*3+i,
												NeuronType::Output)});
	}
 
	// Create weights between hidden and output neurons
	for (size_t i = 0; i < m_hidden_nums; i++) {		
		for (size_t j = 0; j < m_output_nums; j++){
			m_h2o_weights.emplace_back(
				std::shared_ptr<Weight> {new Weight(DIST(gen_value),
													m_hidden_neurons[i],
													m_output_neurons[j])});
		}
    }
}

/**

 **/
double NN::getLearningRate(void) const {
	return m_eta;
}

/**

 **/
double NN::getMomentumRate(void) const {
	return m_delta;
}

/**

 **/
void NN::setLearningRate(double eta) {
	m_eta = eta;
}

/**

 **/
void NN::setMomentumRate(double delta) {
	m_delta = delta;
}
