#ifndef __DEFINE_H__
#define __DEFINE_H__
#include <string>

enum class NeuronType {Input=0, Hidden, Output};

#endif
