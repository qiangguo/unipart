#include "neuron.h"

/**

 **/
size_t Neuron::getID(void) const {
	return m_id;
}


void Neuron::feedForward(void) {

}
