#include "weight.h"

/**
    
 **/
double Weight::getValue(void) const {
	return m_val;
}

/**
    
 **/
void Weight::setValue(double val) {
	m_val = val;
}


/**

 **/
std::shared_ptr<Neuron> Weight::getInputNeuron(void) const {
	return m_input_neuron;
}


/**

 **/
std::shared_ptr<Neuron> Weight::getOutputNeuron(void) const {
	return m_output_neuron;
}
